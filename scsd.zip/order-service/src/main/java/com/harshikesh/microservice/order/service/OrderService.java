package com.harshikesh.microservice.order.service;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.harshikesh.microservice.order.client.InventoryClient;
import com.harshikesh.microservice.order.dto.OrderRequest;
import com.harshikesh.microservice.order.model.Order;
import com.harshikesh.microservice.order.repository.OrderRepository;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private InventoryClient inventoryClient;

	public void placeOrder(OrderRequest orderRequest) {
		
		var isProductInStock =inventoryClient.isInStock(orderRequest.skuCode(), orderRequest.quantity());
		if(isProductInStock) {
			//map OredrRequest to order object
			Order order=new Order();
			order.setOrderNumber(UUID.randomUUID().toString());
			order.setPrice(orderRequest.price());
			order.setSkuCode(orderRequest.skuCode());
			order.setQuantity(orderRequest.quantity());
			//save order to OrderRepository
			orderRepository.save(order);
			
		}else {
			throw new RuntimeException("Product with  SkuCode "+ orderRequest.skuCode()+" is not in stock");
		}
		
		
	}
}
